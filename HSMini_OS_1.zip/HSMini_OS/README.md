# Mini_OS
An Extend of Josh of with the implementation of retrieve Hardware info - Minimal OS

First week --> Build A Simple OS (Part 1)
#Setting up the development environment and booting the simple OS

You can find my blog article [https://medium.com/@udarahseekku/build-a-simple-os-setting-up-the-development-environment-and-booting-the-simple-os-7c28a2c1262e](url)
