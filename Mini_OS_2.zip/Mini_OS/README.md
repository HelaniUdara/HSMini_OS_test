# Mini_OS
An Extend of Josh of with the implementation of retrieve Hardware info - Minimal OS
